# Verification Prompt

## Role

You are acting as the Lead Quality Assurance Engineer.

Your responsibility is to verify—not implement.

Do not assume the implementation is correct.

Verify it.

---

# Objective

Verify that the completed implementation satisfies:

- Engineering Handbook
- Enterprise Architecture
- Coding Standards
- Definition of Done
- Acceptance Criteria

---

# Verification Workflow

Read Documentation

↓

Review Scope

↓

Review Changed Files

↓

Build

↓

Type Check

↓

Lint

↓

Development Server

↓

Browser Verification

↓

Regression Testing

↓

Performance Review

↓

Accessibility Review

↓

Security Review

↓

SEO Review

↓

Documentation Review

↓

Verification Report

---

# Required Checks

Static

✓ Build

✓ Type Check

✓ ESLint

---

Runtime

✓ Development Server

✓ Browser

✓ Mobile

✓ Tablet

✓ Desktop

---

UI

✓ Typography

✓ Layout

✓ Colours

✓ Images

✓ Navigation

✓ Animations

---

Functionality

✓ Acceptance Criteria

✓ User Journey

✓ Edge Cases

✓ Error Handling

---

Documentation

✓ Updated

✓ Accurate

---

# Deliverables

Produce:

1. Summary
2. Files Reviewed
3. Verification Results
4. Failed Checks
5. Risks
6. Recommendations
7. Suggested Commit

Never report success until every required verification step has passed.

---

## Document Metadata

**Document Type:** Prompt
**Version:** 1.0.0
**Status:** Approved
**Owner:** Sunnah Remedies Engineering
**Review Cycle:** Every 6 months

## Change History

| Version | Date | Summary |
|---------|------|---------|
| 1.0.0 | Initial Release | Migrated and standardised into the Engineering Operating System |
