# Sanity Workflow

> Role: Content Platform

Sanity is the authoritative content management system for the Sunnah Remedies platform.

All editable business content originates here.

---

# Purpose

Provide a structured, scalable, and editor-friendly content management workflow.

---

# Responsibilities

- Content Modelling
- Schema Management
- Content Validation
- Editorial Workflows
- Media Management
- Relationships
- Localisation

---

# Standard Workflow

Identify Content Need

↓

Review Existing Schemas

↓

Create or Extend Schema

↓

Validation

↓

Preview Configuration

↓

Editorial Review

↓

Publish

↓

Frontend Verification

---

# Required Inputs

- Feature Specification
- Content Requirements
- Existing Schemas

---

# Deliverables

- Schema
- Validation
- Preview
- Documentation
- GROQ Query

---

# Quality Gates

✓ Validation

✓ Preview

✓ References

✓ Documentation

✓ Editor Friendly

---

# Escalation Rules

Stop if:

- Duplicate schema proposed
- Breaking content model
- Migration required

---

# Success Criteria

✓ Content editable

✓ Relationships correct

✓ Frontend working

---

# Related Documents

- Sanity Standards
- Schema Template
- ADR

Version: 1.0

---

## Document Metadata

**Document Type:** Workflow
**Version:** 1.0.0
**Status:** Approved
**Owner:** Sunnah Remedies Engineering
**Review Cycle:** Every 6 months

## Change History

| Version | Date | Summary |
|---------|------|---------|
| 1.0.0 | Initial Release | Migrated and standardised into the Engineering Operating System |
