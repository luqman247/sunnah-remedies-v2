# Prompt Writing Standard

## Purpose

Establish a consistent structure for writing reusable engineering prompts.

Well-written prompts produce predictable, high-quality outputs.

---

# Prompt Philosophy

Every prompt should be:

- Clear
- Specific
- Context-aware
- Goal-oriented
- Measurable
- Reusable
- Version controlled

Prompts are engineering assets.

---

# Standard Structure

Every prompt must contain:

1. Title
2. Purpose
3. Role
4. Objective
5. Context
6. Inputs
7. Responsibilities
8. Constraints
9. Deliverables
10. Acceptance Criteria
11. Related Documents
12. Version

---

# Writing Rules

Always:

- Define a single objective.
- Define the AI role.
- Provide project context.
- Specify expected output.
- State verification requirements.
- Define success criteria.

Avoid:

- Ambiguous language.
- Multiple unrelated objectives.
- Undefined scope.
- Assumptions.
- Missing context.

---

# Prompt Categories

- Architecture
- Planning
- Implementation
- Verification
- Documentation
- Security
- Performance
- Accessibility
- SEO
- Deployment

---

# Review Checklist

Before approving a prompt:

✓ Objective clear

✓ Scope defined

✓ Deliverables listed

✓ Constraints listed

✓ Version added

✓ Related documents referenced

---

# Principles Summary

1. Every prompt has one purpose.
2. Context improves quality.
3. Scope prevents ambiguity.
4. Reusable prompts reduce inconsistency.
5. Prompt quality directly affects engineering quality.

Version: 1.0

---

## Document Metadata

**Document Type:** Standard
**Version:** 1.0.0
**Status:** Approved
**Owner:** Sunnah Remedies Engineering
**Review Cycle:** Every 6 months

## Change History

| Version | Date | Summary |
|---------|------|---------|
| 1.0.0 | Initial Release | Migrated and standardised into the Engineering Operating System |
